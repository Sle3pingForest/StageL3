This module provides fast computation of distance between strings.

--------------------------------------------------
1. Install
--------------------------------------------------
From this directory (-e is optional):
> sudo -H pip install [-e] .

Or from the parent directory:
> sudo -H pip install [-e] analogy_in_C

--------------------------------------------------
2. Usage
--------------------------------------------------
Help:
 > python tests/nlg_benchmark.py -h
…
 > python tests/nlg_benchmark.py —help
…
 > python tests/nlg_benchmark.py < benchmark_positive.txt
…
 > python tests/nlg_benchmark.py < benchmark_negative.txt
…

--------------------------------------------------
3. Uninstall
--------------------------------------------------
> sudo -H pip uninstall analogy_in_C
