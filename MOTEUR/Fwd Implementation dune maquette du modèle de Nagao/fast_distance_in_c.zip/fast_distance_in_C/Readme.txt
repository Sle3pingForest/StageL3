This module provides fast computation of distance between strings.

--------------------------------------------------
1. Install
--------------------------------------------------
From this directory:
> sudo -H pip install -e .

Or from the parent directory:
> sudo -H pip install -e fast_distance_in_C

--------------------------------------------------
2. Usage
--------------------------------------------------
Help:
 > python fast_distance -h
…
 > python fast_distance.py —help
…

--------------------------------------------------
3. Uninstall
--------------------------------------------------
> sudo -H pip uninstall fast_distance
