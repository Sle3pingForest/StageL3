/* File: bitcount.h */
int wegner_bitcount(char *wp, int nwords) ;
int bitcount(char *wp, int nwords) ;
